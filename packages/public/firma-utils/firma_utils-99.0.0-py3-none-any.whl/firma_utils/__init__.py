__version__ = "99.0.0"

SOURCE = "oeffentliche Paketquelle (Angriff)"
