__version__ = "99.0.0"

SOURCE = "public package index (attack)"
